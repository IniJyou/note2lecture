---
lang: zh-CN
title: 用 Obsidian 记一次均值计算
---
```{=latex}
% N2L_SOURCE 3 0
```
这是一份原创的功能样例，用一组可手算的数据展示笔记中的链接、图片和提示框。

```{=latex}
% N2L_SOURCE 5 1
```
# 三个数的均值 {#sec-n2l-1}

```{=latex}
% N2L_SOURCE 7 2
```
设三个数为 $\NtwoLMathToken{4592237409c0362f4c79c1e38671fcc689f9581570bd2e6265c0299f8552353b}$。总和是 $\NtwoLMathToken{e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb}$，数据个数是 $\NtwoLMathToken{4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce}$，所以算术平均为

```{=latex}
% N2L_SOURCE 9 3
```
`\NtwoLMathDisplay{8f9a0f2689056f517a64942c1ed6d46f3b9ac031170d7f29c42e039e1161c584}{\NtwoLMathToken{8f9a0f2689056f517a64942c1ed6d46f3b9ac031170d7f29c42e039e1161c584}}`{=latex}

```{=latex}
% N2L_SOURCE 13 4
```
相关笔记是 01-mean（关联笔记：`\texttt{01-mean.\allowbreak{}md}`{=latex}）。也可以用更易读的说明指向同一篇笔记：算术平均的基础笔记（关联笔记：`\texttt{01-mean.\allowbreak{}md}`{=latex}）。

```{=latex}
% N2L_SOURCE 15 5
```
::: n2l-callout
**笔记：平均值回答什么问题**

在总量不变的条件下，平均值表示每个位置分到多少。本例中每个位置分到 $\NtwoLMathToken{ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d}$。
:::

```{=latex}
% N2L_SOURCE 18 6
```
# 计算顺序 {#sec-n2l-2}

```{=latex}
% N2L_SOURCE 20 7
```
![`mean-flow.\allowbreak{}png`{=latex}](assets/032eb3cddc991a8cc9cb5af6d78bfe9fbae9e484d7c2e500316bb9d1348c7906.png){#fig-n2l-1 width="160.000mm"}

```{=latex}
% N2L_SOURCE 22 8
```
图示说明：先求三个数的总和，再除以数据个数。图片不表示需要先给数据排序。

```{=latex}
% N2L_SOURCE 24 9
```
::: n2l-callout
**提示：手算复核**

先确认 $\NtwoLMathToken{d3650ddd18ad389d7d4b73c2aff54863901b327cc5e8626165ffe1897e56f853}$，再确认 $\NtwoLMathToken{23cb571f38b499e7f31ab855c0f9eb7fc5db100f8ebe0222c79639292c900460}$。计算结束后，可以跳到 [复核结果](#sec-n2l-3)。
:::

```{=latex}
% N2L_SOURCE 27 10
```
::: n2l-callout
**注意：不要混淆概念**

这三个数的中位数是 $\NtwoLMathToken{4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a}$，算术平均是 $\NtwoLMathToken{ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d}$。两者回答的问题不同。
:::

```{=latex}
% N2L_SOURCE 30 11
```
# 复核结果 {#sec-n2l-3}

```{=latex}
% N2L_SOURCE 32 12
```
平均值 $\NtwoLMathToken{ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d}$ 位于最小值 $\NtwoLMathToken{d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35}$ 和最大值 $\NtwoLMathToken{19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7}$ 之间；这个条件可用于快速排查明显错误，但不能单独证明计算正确。

```{=latex}
% N2L_SOURCE 34 13
```
回看 [计算顺序](#sec-n2l-2)，确认分母使用的是数据个数。

```{=latex}
% N2L_SOURCE 36 14
```
# 字面文本 {#sec-n2l-4}

```{=latex}
% N2L_SOURCE 38 15
```
下面代码块中的记号只作为文字展示，不应解析成链接、图片或提示框，也不执行代码。

```{=latex}
% N2L_SOURCE 41 16
```
``` {.text n2l-code="code/7eece7a95bb42a4577001f96ed90f5b8a0afb086ff63596e3f55306968405465.txt"}
[[这里不是要读取的笔记]]
![[这里不是要读取的图片.png]]
> [!note] 这里只是文字
```
