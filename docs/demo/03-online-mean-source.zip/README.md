# 可编辑 LaTeX 源包

入口是 main.tex。图片位于 assets/，代码原文位于 code/（若有），样式位于 template/。
在全新目录首次编译，或修改正文导致目录、分页变化时，建议运行三轮 XeLaTeX：

```powershell
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode main.tex
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode main.tex
xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode main.tex
```

检查 main.log；若仍提示 Rerun，应继续编译至目录页码和引用收敛。
这里不调用 Quarto、Python、模型或原笔记目录，也不需要下载。
请保留所有资源和样式。字体采用 TeX Live 中的 Fandol 宋/黑/仿宋与 Latin Modern；
所需宏包包括 ctex、unicode-math、amsmath、amsthm、graphicx、geometry、longtable、
booktabs、caption、fvextra、fancyhdr、needspace、setspace、hyperref 等。
依赖的实际工具版本及字体摘要见 manifest.json。字体文件未随包分发。

normalized.md 是生成过程的工作副本，不是原稿；引用已转换为受控 LaTeX，
资源路径和代码块属性已经重写。render-config.yml 记录受控渲染设置。
仅重新编译 main.tex 不依赖这些 Markdown 渲染工具。
输出 PDF 不表示已通过内容、页面或风格检查，检查状态见上级 diagnostics.json。
