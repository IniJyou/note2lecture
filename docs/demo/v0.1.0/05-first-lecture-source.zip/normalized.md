---
lang: zh-CN
title: 从笔记到讲义：一次计算复核
---
```{=latex}
% N2L_SOURCE 3 0
```
# 写下问题 {#sec-n2l-1}

```{=latex}
% N2L_SOURCE 5 1
```
一份可以复查的笔记，应当同时保存问题、计算条件和检查方法。 这里取三个观测值 $\NtwoLMathToken{d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35}$、$\NtwoLMathToken{4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a}$、$\NtwoLMathToken{19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7}$，用算术平均表示它们的中心位置。 样例中的文字、数值与命令为公开演示编写，命令只用于排版，不会运行。

```{=latex}
% N2L_SOURCE 9 2
```
`\NtwoLMathDisplay{8f9a0f2689056f517a64942c1ed6d46f3b9ac031170d7f29c42e039e1161c584}{\NtwoLMathToken{8f9a0f2689056f517a64942c1ed6d46f3b9ac031170d7f29c42e039e1161c584}}`{=latex}

```{=latex}
% N2L_SOURCE 13 3
```
![三个输入先求和，再除以数量](assets/032eb3cddc991a8cc9cb5af6d78bfe9fbae9e484d7c2e500316bb9d1348c7906.png){#fig-n2l-1 width="160.000mm"}

```{=latex}
% N2L_SOURCE 15 4
```
# 保留推导与条件 {#sec-n2l-2}

```{=latex}
% N2L_SOURCE 17 5
```
令候选中心为 $\NtwoLMathToken{ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb}$，三个观测值到它的平方距离之和为

```{=latex}
% N2L_SOURCE 19 6
```
`\NtwoLMathDisplay{d1cf562fc72b6765751f4473c9123acf63e0b83ba82ce7b62d3afdbc55be295f}{\NtwoLMathToken{d1cf562fc72b6765751f4473c9123acf63e0b83ba82ce7b62d3afdbc55be295f}}`{=latex}

```{=latex}
% N2L_SOURCE 23 7
```
平方项非负，所以当 $\NtwoLMathToken{10cd4469471625e73431a4982adc50aca851b24f5735dbf242e5b59cbde42b60}$ 时取得最小值。这个结论保留了计算的对象， 也说明了为什么平均值适合作为这组三个数的中心。

```{=latex}
% N2L_SOURCE 26 8
```
| 检查项   | 本例结果 |
|----------|----------|
| 观测数量 | 三个     |
| 数值总和 | 十五     |
| 平均值   | 五       |

```{=latex}
% N2L_SOURCE 32 9
```
# 保存可复查的操作 {#sec-n2l-3}

```{=latex}
% N2L_SOURCE 34 10
```
JSON 可以记录一个简短的实验配置。下面的字段作为代码正文保留， 不会变成转换器设置。

```{=latex}
% N2L_SOURCE 38 11
```
``` {n2l-code="code/383571dc056a68519f726c221521dcd110540a53e888ee9ad96656f404723f07.txt"}
{"values": [2, 4, 9], "method": "mean", "expected": 5}
```

```{=latex}
% N2L_SOURCE 41 12
```
PowerShell 命令展示怎样检查一篇普通 Markdown 笔记。这里写的是相对路径， 实际使用时可以替换成自己的文件。

```{=latex}
% N2L_SOURCE 45 13
```
``` {n2l-code="code/4b4bf5a4d5495d620655ec3171179aafd987ae848dc06a36174359ccecf1aea4.txt"}
$notePath = 'examples/05-first-lecture.md'
.\.venv\Scripts\python.exe note2lecture.py check $notePath --profile markdown
```

```{=latex}
% N2L_SOURCE 49 14
```
转换后先阅读 PDF，再保留完整 LaTeX 源包。两者配合，既方便阅读， 也允许之后继续修改文字和公式；原始笔记仍作为独立来源保存。
