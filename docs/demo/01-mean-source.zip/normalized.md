---
author: Note2Lecture 示例
date: '2026-10-23'
lang: zh-CN
title: 从三个数理解算术平均
---
```{=latex}
% N2L_SOURCE 8 0
```
# 平均值的含义 {#sec-mean}

```{=latex}
% N2L_SOURCE 10 1
```
把三个相同容量的杯子想成三个数的位置。我们只关心每个位置上的数，不涉及测量误差。**算术平均**回答的是：如果总量不变，每个位置分到多少？[^1]

```{=latex}
% N2L_SOURCE 12 2
```
设 $n$ 为正整数，$x_1,\ldots,x_n\in\mathbb{R}$。它们的算术平均为

```{=latex}
% N2L_SOURCE 14 3
```
$$
\bar{x}=\frac{1}{n}\sum_{i=1}^{n}x_i.
$$ {#eq-mean}

```{=latex}
% N2L_SOURCE 18 4
```
对于 $2,4,9$，总和为 $15$，所以 $\bar{x}=5$。不要把*平均值*和“序列中间位置的值”混为一谈；这里的中位数是 $4$。

```{=latex}
% N2L_SOURCE 20 5
```
## 手算顺序 {#sec-steps}

```{=latex}
% N2L_SOURCE 22 6
```
1.  数清数据个数，本例为 $n=3$。
2.  计算总和 $2+4+9=15$。
3.  用总和除以个数，得到 $15/3=5$。

```{=latex}
% N2L_SOURCE 26 7
```
![先求总和，再除以数据个数](assets/032eb3cddc991a8cc9cb5af6d78bfe9fbae9e484d7c2e500316bb9d1348c7906.png){#fig-mean-flow width="160.000mm"}

```{=latex}
% N2L_SOURCE 28 8
```
`\hyperref[fig-mean-flow]{图~\ref*{fig-mean-flow}}`{=latex} 展示了 `\hyperref[eq-mean]{式~(\ref*{eq-mean})}`{=latex} 的计算顺序；它不要求输入已经排序。

```{=latex}
% N2L_SOURCE 30 9
```
### 简单复核 {#sec-check}

```{=latex}
% N2L_SOURCE 32 10
```
本例的 $5$ 落在最小值 $2$ 与最大值 $9$ 之间。这是一个快速复核线索，但仅凭这个条件还不能确定平均值算对了。

```{=latex}
% N2L_SOURCE 34 11
```
# 写成短程序 {#sec-code}

```{=latex}
% N2L_SOURCE 36 12
```
下面的 Python 代码只是讲义中的内容。`values` 保存原始次序，空输入应当明确报错。

```{=latex}
% N2L_SOURCE 39 13
```
``` {.python n2l-code="code/6cf574cc9e213652d7d255d5c7815d9f73607662128b4d8bb06e687b1f9da932.txt"}
def arithmetic_mean(values):
    # 空序列没有这里定义的算术平均。
    if not values:
        raise ValueError("values must not be empty")
    return sum(values) / len(values)

values = [2, 4, 9]
result = arithmetic_mean(values)  # 手算期望值：5.0
```

```{=latex}
% N2L_SOURCE 49 14
```
复核时注意两点：

```{=latex}
% N2L_SOURCE 51 15
```
- 分母是数据个数，不是最大数。
- 数据可以重复，也可以包含负数。
  - 重复出现的数按实际出现次数计入。
  - 负数保留原来的符号。

```{=latex}
% N2L_SOURCE 56 16
```
计算完成后，可以回到 `\hyperref[sec-check]{第~\ref*{sec-check}~节}`{=latex} 做一次快速复核。

```{=latex}
% N2L_SOURCE 58 17
```
> 一个极端值会拉动算术平均。解释平均值之前，应先说明数据代表什么。

```{=latex}
% N2L_SOURCE 60 18
```
格式记号可对照 [Markdown 语法说明](https://daringfireball.net/projects/markdown/syntax) 阅读；导出时只保留链接，不访问该网页。

[^1]: 本例仅讨论有限个实数的算术平均，不把它当作概率分布期望的一般定义。
